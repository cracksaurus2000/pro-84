# spectagram-stage-4
project solution c84
